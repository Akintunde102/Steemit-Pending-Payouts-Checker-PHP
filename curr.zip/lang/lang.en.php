<?php
/* 
------------------
Language: English
------------------
*/



$lang = array();

$lang['title'] = 'Steem Payout Checker';


$lang['Name'] = 'Steem Payout Checker';
$lang['home_placeholder'] = 'Steem Username';
$lang['home_btnv'] = 'Check';
$lang['codedby'] = '&copy; 2017 Coded By';
$lang['designby'] = '&nbsp; || Design Based On';


$lang['Author'] = 'Author';
$lang['Beneficiary'] = 'Beneficiary';
$lang['PostLink'] = 'Post Link';
$lang['CommentLink'] = 'Comment Link';
$lang['PendingPayout'] = 'Pending Payout' ;
$lang['WithdrawalTime'] = 'Withdrawal Time';
$lang['Parent'] = 'Parent';
$lang['YourExpectedPayout'] = 'Your Expected Payout';
$lang['PrintSlip'] = 'Print Slip';
$lang['Conversion'] = 'Conversion';
$lang['PostPayout'] = 'Post\'s Payout';
$lang['TotalPayout'] = 'Total Payout';
$lang['CommentPayout'] = 'Comment\'s Payout';
$lang['ImgWeekPay'] = '\'s Weekly Payout';
$lang['EnglishTranslate'] = 'ENGLISH';
$lang['SpanishTranslate'] = 'SPANISH';
$lang['giver'] = 'Highest Giver';
$lang['Voterslist'] = 'Voter\'s  List';
$lang['ExchangeRate'] = 'Exchange Rate';
