<?php
/* 
------------------
Language: Spanish
------------------
*/



$lang = array();

$lang['title'] = 'Comprobador de pago Steem';


$lang['Name'] = 'Comprobador de pago Steem';
$lang['home_placeholder'] = 'Usuario de Steem';
$lang['home_btnv'] = 'comprobar';
$lang['codedby'] = '&copy; 2017 codificado por';
$lang['designby'] = '&nbsp; || diseñada por';


$lang['Author'] = 'Autor';
$lang['Beneficiary'] = 'Beneficiario';
$lang['PostLink'] = 'Enlace de Publicación';
$lang['CommentLink'] = 'Enlace de Comentario';
$lang['PendingPayout'] = 'Pago pendiente' ;
$lang['WithdrawalTime'] = 'Tiempo de retiro';
$lang['Parent'] = 'Enlace Superior';
$lang['YourExpectedPayout'] = 'Su Pago Esperado';
$lang['PrintSlip'] = 'Imprimir comprobante';
$lang['Conversion'] = 'Conversión';
$lang['PostPayout'] = 'Pago de Publicación';
$lang['TotalPayout'] = 'Pago total';
$lang['CommentPayout'] = 'Comentario de pago';
$lang['ImgWeekPay'] = '\'s Pago semanal';
$lang['EnglishTranslate'] = 'Inglés';
$lang['SpanishTranslate'] = 'Español';
$lang['giver'] = 'Mayor dador';
$lang['ExchangeRate'] = 'Exchange Rate';