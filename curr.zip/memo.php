<?php
 include('models/post.php');
   echo 'nonsense';
      $b = new post;
	   $b->sendmemo();
	
	?>