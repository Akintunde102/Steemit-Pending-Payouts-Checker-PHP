<div id="particles-js"></div>
<div class="main-akin">
	<div class="akin-newsletter">
		<h1>Steem Payout Checker</h1>
		<img src="views/pages/assets/images/mk.png" alt="">
		<div class="subsc-w3l"><form action="" >
			<input type="text" style="width: 100%;" name="username" required="" placeholder="steem username" />
			</div>
		</form>
		<p align="center" style="margin: 10px 3px 3px 193px;"><span> &copy; 2018 Designed By</span> <a href="http://steemit.com/@akintunde">@akintunde</a></p>
	</div>
		
</div>