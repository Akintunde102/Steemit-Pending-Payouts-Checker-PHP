<!DOCTYPE html>
<html lang="en">
<head>
<title><?=$lang['Name']?></title>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Fantasy Coming Soon Responsive Widget,Login form widgets, Sign up Web forms , Login signup Responsive web form,Flat Pricing table,Flat Drop downs,Registration Forms,News letter Forms,Elements" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script> 
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.tablesorter/2.29.2/js/jquery.tablesorter.js"></script> 

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } 

//Table
$(function(){
  $('#keywords').tablesorter(); 
});
//Table
$(function(){
  $('#keywords2').tablesorter(); 
});
</script>
<!-- CSS --> 
<link href="views/pages/assets/css/font-awesome.css" rel="stylesheet"><!-- Font-awesome-CSS --> 
<link href="views/pages/assets/css/style.css" rel='stylesheet' type='text/css'/><!-- style.css --> 
<!-- //CSS --> 
<!-- Fonts --> 
<link href="//fonts.googleapis.com/css?family=Josefin+Sans:100,100i,300,300i,400,400i,600,600i,700,700i&amp;subset=latin-ext" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Oswald:200,300,400,500,600,700&amp;subset=cyrillic,latin-ext,vietnamese" rel="stylesheet">
<!-- Fonts --> 
</head>
<body>
    <?php require_once('routes.php'); ?>
<!-- Js-Files --> 
	<script src="views/pages/assets/js/particles.js"></script>
	<script src="views/pages/assets/js/app.js"></script>
<!-- //Js-Files --> 

</body>
</html>